#ifndef EVALUATEUR_H
#define EVALUATUEUR_H
#include "jeton.h"

float Evaluateur(Noeud* ArbreBin, float x, TypeErreur * Erreur);

#endif
