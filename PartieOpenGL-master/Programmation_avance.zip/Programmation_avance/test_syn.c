#include "test_syn.h"


void test(typejeton Syntaxe[TAILLE_TAB_JETONS], int NumTest){
    switch(NumTest){
        
        case 1:
            printf("TEST 1: Objectif : Verifier que l analyse syntaxique gere le cas de l'absence du signe  *\nCas particuliers traites : \n1) 5x -> 5*x \n2) x(5*x+1) -> x*(5*x+1)\nErreur attendue : AUCUNE");
            printf("\n\n Fonction: f(x) = x(5x+1)\n\n");
            Syntaxe[0].lexem = VARIABLE;
            Syntaxe[1].lexem = PAR_OUV;
            Syntaxe[2].lexem = REEL;
            Syntaxe[2].valeur.reel = 5;
            Syntaxe[3].lexem = VARIABLE;
            Syntaxe[4].lexem = OPERATEUR;
            Syntaxe[4].valeur.operateur = PLUS;
            Syntaxe[5].lexem = REEL;
            Syntaxe[5].valeur.reel = 1;
            Syntaxe[6].lexem = PAR_FERM;
            Syntaxe[7].lexem = FIN;
            break;
        case 2:
            printf("TEST 2:  f(x) = (x+5)5\nObjectif : Verifier que l analyse syntaxique gere le cas de l absence du signe *\nErreur attendue : ERREUR_ABS_SIGNE_FOIS");
            Syntaxe[0].lexem = PAR_OUV;
            Syntaxe[1].lexem = REEL;
            Syntaxe[1].valeur.reel = 5;
            Syntaxe[2].lexem = VARIABLE;
            Syntaxe[3].lexem = OPERATEUR;
            Syntaxe[3].valeur.operateur = PLUS;
            Syntaxe[4].lexem = REEL;
            Syntaxe[4].valeur.reel = 1;
            Syntaxe[5].lexem = PAR_FERM;
            Syntaxe[6].lexem = VARIABLE;
            Syntaxe[7].lexem = FIN;
            break;
        case 3:
            printf("TEST 3:  f(x) = x++x\nObjectif : Verifier que l analyse syntaxique gere les doublons d operateurs \nErreur attendue : ERREUR_OPERATEUR");
            Syntaxe[0].lexem = VARIABLE;
            Syntaxe[1].lexem = OPERATEUR;
            Syntaxe[1].valeur.operateur = PLUS;
            Syntaxe[2].lexem = OPERATEUR;
            Syntaxe[2].valeur.operateur = PLUS;
            Syntaxe[3].lexem = VARIABLE;
            Syntaxe[4].lexem = FIN;
            break;

        case 4:
            printf("TEST 4:  f(x) = *x \nObjectif : Verifier que l analyse syntaxique gere le cas d un operateur * sans expression a sa gauche. \nErreur attendue : ERREUR_OPERATEUR");
            Syntaxe[0].lexem = OPERATEUR;
            Syntaxe[0].valeur.operateur = FOIS;
            Syntaxe[1].lexem = VARIABLE;
            Syntaxe[2].lexem = FIN;
            break;
        case 5:
            printf("\nTEST 5 :  f(x) = -(x+1)+1\n Objectif : Verifier que l analyse syntaxique gere le cas d un operateur - sans expression a gauche.\nErreur attendue : AUCUNE");
            Syntaxe[0].lexem = OPERATEUR;
            Syntaxe[0].valeur.operateur = MOINS;
            Syntaxe[1].lexem = PAR_OUV;
            Syntaxe[2].lexem = VARIABLE;
            Syntaxe[3].lexem = OPERATEUR;
            Syntaxe[3].valeur.operateur = PLUS;
            Syntaxe[4].lexem = REEL;
            Syntaxe[4].valeur.reel = 1;
            Syntaxe[5].lexem = PAR_FERM;
            Syntaxe[6].lexem = OPERATEUR;
            Syntaxe[6].valeur.operateur = PLUS;
            Syntaxe[7].lexem = REEL;
            Syntaxe[7].valeur.reel = 1;
            Syntaxe[8].lexem = FIN;
            break;

        case 6:
            printf("TEST 6:  f(x) = )5( \nObjectif : Verifier que l analyse syntaxique gere les erreurs liees aux parentheses. \nErreur attendue : ERREUR_PARENTHESES");
            Syntaxe[0].lexem = PAR_FERM;
            Syntaxe[1].lexem = REEL;
            Syntaxe[1].valeur.reel = 5;
            Syntaxe[2].lexem = PAR_OUV;
            Syntaxe[3].lexem = FIN;
            break;
        case 7:
            printf("TEST 7:  f(x) = (5 \nObjectif : Verifier que l analyse syntaxique gere les erreurs liees aux parentheses. \nErreur attendue : ERREUR_PARENTHESES");
            Syntaxe[0].lexem = PAR_OUV;
            Syntaxe[1].lexem = REEL;
            Syntaxe[1].valeur.reel = 5;
            Syntaxe[2].lexem = FIN;
            break;

        case 8:
            printf("TEST 8:  f(x) = sin cos sqrt 3 * 6 \nObjectif : Verifier que l analyse syntaxique gere les erreurs liees aux fonctions. \nErreur attendue : AUCUNE");
            Syntaxe[0].lexem = FONCTION;
            Syntaxe[0].valeur.fonction = SIN;
            Syntaxe[1].lexem = FONCTION;
            Syntaxe[1].valeur.fonction = COS;
            Syntaxe[2].lexem = FONCTION;
            Syntaxe[2].valeur.fonction = SQRT;
            Syntaxe[3].lexem = REEL;
            Syntaxe[3].valeur.reel = 3;
            Syntaxe[4].lexem = OPERATEUR;
            Syntaxe[4].valeur.operateur = FOIS;
            Syntaxe[5].lexem = REEL;
            Syntaxe[5].valeur.reel = 6;
            Syntaxe[6].lexem = FIN;
            break;

        case 9:
            printf("TEST 9:  f(x) = sin (cos 6 + sqrt 3)+1  \nObjectif : Verifier que l analyse syntaxique gere les erreurs liees aux fonctions. \nErreur attendue : AUCUNE");
            Syntaxe[0].lexem = FONCTION;
            Syntaxe[0].valeur.fonction = SIN;
            Syntaxe[1].lexem = PAR_OUV;
            Syntaxe[2].lexem = FONCTION;
            Syntaxe[2].valeur.fonction = COS;
            Syntaxe[3].lexem = REEL;
            Syntaxe[3].valeur.reel = 6;
            Syntaxe[4].lexem = OPERATEUR;
            Syntaxe[4].valeur.operateur = PLUS;
            Syntaxe[5].lexem = FONCTION;
            Syntaxe[5].valeur.fonction = SQRT;
            Syntaxe[6].lexem = REEL;
            Syntaxe[6].valeur.reel = 3;
            Syntaxe[7].lexem = PAR_FERM;
            Syntaxe[8].lexem = OPERATEUR;
            Syntaxe[8].valeur.operateur = PLUS;
            Syntaxe[9].lexem = REEL;
            Syntaxe[9].valeur.reel = 1;
            Syntaxe[10].lexem = FIN;
            break;
        case 10:
            printf("TEST 10: Objectif : Verifier que l analyse syntaxique gere le cas de l'absence du signe et de parenthèses dans le cas de fonctions  *\nCas d un signe fois fantome pour une fonction\nErreur attendue : AUCUNE");
            printf("\n\n Fonction: f(x) = 1 + 6x sin 5x\n\n");
            Syntaxe[0].lexem = REEL;
            Syntaxe[0].valeur.reel = 1;
            Syntaxe[1].lexem = OPERATEUR;
            Syntaxe[1].valeur.operateur = PLUS;
            Syntaxe[2].lexem = REEL;
            Syntaxe[2].valeur.reel = 6;
            Syntaxe[3].lexem = VARIABLE;
            Syntaxe[4].lexem = FONCTION;
            Syntaxe[4].valeur.fonction = SIN;
            Syntaxe[5].lexem = REEL;
            Syntaxe[5].valeur.reel = 5;
            Syntaxe[6].lexem = VARIABLE;
            Syntaxe[7].lexem = FIN;
            break;
        case 11:
            printf("TEST 11: Objectif : Verifier que l analyse syntaxique gere le cas de l'absence du signe dans le cas de fonctions\nErreur attendue : AUCUNE");
            printf("\n\n Fonction: f(x) = sin 5x cos sin 6x + 1\n\n");
            Syntaxe[0].lexem = FONCTION;
            Syntaxe[0].valeur.fonction = SIN;
            Syntaxe[1].lexem = REEL;
            Syntaxe[1].valeur.reel = 5;
            Syntaxe[2].lexem = VARIABLE;

            Syntaxe[3].lexem = FONCTION;
            Syntaxe[3].valeur.fonction = COS;
            Syntaxe[4].lexem = FONCTION;
            Syntaxe[4].valeur.fonction = SIN;
            Syntaxe[5].lexem = REEL;
            Syntaxe[5].valeur.reel = 6;
            Syntaxe[6].lexem = VARIABLE;
            Syntaxe[7].lexem = OPERATEUR;
            Syntaxe[7].valeur.operateur = PLUS;
            Syntaxe[8].lexem = REEL;
            Syntaxe[8].valeur.reel = 1;
            Syntaxe[9].lexem = FIN;
            break;
        case 12:
            printf("\n\nTEST 12: Objectif : Tester une fonction sans parametre \nErreur attendue : ERREUR_FCT_SANS_PARAM");
            printf("\n\n Fonction: f(x) = sin ()\n\n");
            Syntaxe[0].lexem = FONCTION;
            Syntaxe[0].valeur.fonction= SIN;
            Syntaxe[1].lexem = PAR_OUV;
            Syntaxe[2].lexem = PAR_FERM;
            Syntaxe[3].lexem = FIN;
            break;

        case 101:
            Syntaxe[0].lexem = REEL;
            Syntaxe[0].valeur.reel = 3;

            Syntaxe[1].lexem = OPERATEUR;
            Syntaxe[1].valeur.operateur = PLUS;

            Syntaxe[2].lexem = REEL;
            Syntaxe[2].valeur.reel = 6;

            Syntaxe[3].lexem = OPERATEUR;
            Syntaxe[3].valeur.operateur = FOIS;

            Syntaxe[4].lexem = FONCTION;
            Syntaxe[4].valeur.fonction = SIN;

            Syntaxe[5].lexem = PAR_OUV;

            Syntaxe[6].lexem = REEL;
            Syntaxe[6].valeur.reel = 9;

            Syntaxe[7].lexem = OPERATEUR;
            Syntaxe[7].valeur.operateur = PLUS;

            Syntaxe[8].lexem = REEL;
            Syntaxe[8].valeur.reel = 4;

            Syntaxe[9].lexem = OPERATEUR;
            Syntaxe[9].valeur.operateur = FOIS;

            Syntaxe[10].lexem = REEL;
            Syntaxe[10].valeur.reel = 2;
            
            Syntaxe[11].lexem = PAR_FERM;

            Syntaxe[12].lexem = FIN;
            for (int i = 12; i<TAILLE_TAB_JETONS;i++){
                Syntaxe[i].lexem = FIN;
            }
            break;
        case 22:
            Syntaxe[0].lexem = OPERATEUR;
            Syntaxe[0].valeur.operateur = MOINS;
            Syntaxe[1].lexem = PAR_OUV;
            Syntaxe[2].lexem = REEL;
            Syntaxe[2].valeur.reel = 2;
            Syntaxe[3].lexem = OPERATEUR;
            Syntaxe[3].valeur.operateur = PLUS;
            Syntaxe[4].lexem = REEL;
            Syntaxe[4].valeur.reel = 3;
            Syntaxe[5].lexem = OPERATEUR;
            Syntaxe[5].valeur.operateur = FOIS;
            Syntaxe[6].lexem = PAR_OUV;
            Syntaxe[7].lexem = REEL;
            Syntaxe[7].valeur.reel = 6;
            Syntaxe[8].lexem = OPERATEUR;
            Syntaxe[8].valeur.operateur = DIV;
            Syntaxe[9].lexem = REEL;
            Syntaxe[9].valeur.reel = 2;
            Syntaxe[10].lexem = PAR_FERM;
            Syntaxe[11].lexem = PAR_FERM;
            Syntaxe[12].lexem = OPERATEUR;
            Syntaxe[12].valeur.operateur = PLUS;
            Syntaxe[13].lexem = REEL;
            Syntaxe[13].valeur.reel = 1;
            Syntaxe[14].lexem = FIN;
            for (int i = 15; i<TAILLE_TAB_JETONS;i++){
                Syntaxe[i].lexem = FIN;
            }
            break;
        case 34:
            Syntaxe[0].lexem = REEL;
            Syntaxe[0].valeur.reel = 3;

            Syntaxe[1].lexem = PAR_OUV;


            Syntaxe[2].lexem = REEL;
            Syntaxe[2].valeur.reel = 6;

            Syntaxe[3].lexem = PAR_FERM;
            Syntaxe[4].lexem = FIN;

            for (int i = 5; i<TAILLE_TAB_JETONS;i++){
                Syntaxe[i].lexem = FIN;
            }
            break;
        case 44:
            printf("TEST 4: Gestion des cas:\n→ 5x = 5*x\n→ cos 5 + 3 = cos(5) +3\n→ x(5+3) = x*(5+3)");
            printf("\n\n Fonction: f(x) = 3x(6/x+cos x + 1)\n\nERREURS ATTENDUES: AUCUNES\n\n");

            Syntaxe[0].lexem = REEL;
            Syntaxe[0].valeur.reel = 3;

            Syntaxe[1].lexem = VARIABLE;
            Syntaxe[2].lexem = PAR_OUV;


            Syntaxe[3].lexem = REEL;
            Syntaxe[3].valeur.reel = 6;

            Syntaxe[4].lexem = OPERATEUR;
            Syntaxe[4].valeur.operateur = DIV;

            Syntaxe[5].lexem = VARIABLE;

            Syntaxe[6].lexem = OPERATEUR;
            Syntaxe[6].valeur.operateur = PLUS;

            Syntaxe[7].lexem = FONCTION;
            Syntaxe[7].valeur.fonction = COS;

            Syntaxe[8].lexem = VARIABLE;

            Syntaxe[9].lexem = OPERATEUR;
            Syntaxe[9].valeur.operateur = PLUS;

            Syntaxe[10].lexem = REEL;
            Syntaxe[10].valeur.reel = 1;

            Syntaxe[11].lexem = PAR_FERM;
            Syntaxe[12].lexem = FIN;

            for (int i = 13; i<TAILLE_TAB_JETONS;i++){
                Syntaxe[i].lexem = FIN;
            }
            break;
        case 54:
            Syntaxe[0].lexem = OPERATEUR;
            Syntaxe[0].valeur.operateur = MOINS;

            Syntaxe[1].lexem = REEL;
            Syntaxe[1].valeur.reel = 3;
            Syntaxe[2].lexem = OPERATEUR;
            Syntaxe[2].valeur.operateur = FOIS;


            Syntaxe[3].lexem = REEL;
            Syntaxe[3].valeur.reel = 6;

            Syntaxe[4].lexem = OPERATEUR;
            Syntaxe[4].valeur.operateur = PLUS;

            Syntaxe[5].lexem = REEL;
            Syntaxe[5].valeur.reel = 3;
            Syntaxe[6].lexem = FIN;
            for (int i = 7; i<TAILLE_TAB_JETONS;i++){
                Syntaxe[i].lexem = FIN;
            }
            break;
        case 61:
            Syntaxe[0].lexem = OPERATEUR;
            Syntaxe[0].valeur.operateur = PLUS;

            
            Syntaxe[1].lexem = OPERATEUR;
            Syntaxe[1].valeur.operateur = PLUS;

            Syntaxe[2].lexem = REEL;
            Syntaxe[2].valeur.reel = 6;

            for (int i = 3; i<TAILLE_TAB_JETONS;i++){
                Syntaxe[i].lexem = FIN;
            }
            break;
        default:
            Syntaxe[0].lexem = FIN;

        
        
    }
    
}

void AfficherJetons(typejeton Syntaxe[TAILLE_TAB_JETONS],  int IndexFin, TypeErreur * Erreur){
    int i =0;
    printf("[%s", nom_jeton(Syntaxe[i], Erreur));
    
    while (i<IndexFin && Syntaxe[i].lexem != FIN){
        i++;
        printf(", %s", nom_jeton(Syntaxe[i], Erreur));
        
    }
    printf("]\n");
}

char * nom_jeton(typejeton jeton, TypeErreur * Erreur){
    char * text = (char*)malloc(20*sizeof(char));
    switch (jeton.lexem){
        case REEL:
            sprintf(text,"%d",(int)jeton.valeur.reel); 
            break;

        case PAR_OUV:
            strcpy(text, "PAR_OUV");
            break;
        
        case PAR_FERM:
            strcpy(text, "PAR_FERM");
            break;
  
        case OPERATEUR:
            char operateur[5] = {'+', '-', '*', '/', '^'};
            int index_ope = jeton.valeur.operateur;
            if (index_ope>=0 && index_ope<5){
                text[0] =  operateur[index_ope]; 
                text[1] = '\0';
            }
            else{
                *Erreur = ERREUR_OPE_INCO;
                strcpy(text, "OPE");
            }
            break;

        case FONCTION:
            char * fonction[9] = { "SIN", "COS", "ABS", "SQRT", "LOG", "TAN", "EXP", "ENTIER", "VAL_NEG"};
            int index_fct = jeton.valeur.fonction;
            if (index_fct>=0 && index_fct<9){
                strcpy(text, fonction[index_fct]);
            }
            else{
                *Erreur = ERREUR_FCT_INCO;
                strcpy(text, "FCT");
            }
            break;

        case VARIABLE:
            text[0] = 'X';
            text[1] = '\0';
            break;

        case FIN:
            strcpy(text, "FIN");
            break;

        case ERREUR:
            char * erreur[13] = {"AUCUNE", "ERREUR_ABS_SIGNE_FOIS", "ERREUR_OPERATEUR", "ERREUR_PARENTHESES", "ERREUR_FCT_SANS_PARAM","ERREUR_TROP_CARACT_FANT"
            ,"EREUR_MALLOC","ERREUR_FCT_INCO","ERREUR_OPE_INCO","ERREUR_JETON_INCO", "ERREUR_CHAR_INCO","ERREUR_REEL_INVALIDE", "ERREUR_DIV_PAR_ZERO"};
            int index_erreur = jeton.valeur.erreur;

            if (index_erreur>=0 && index_erreur<13){
                strcpy(text, erreur[index_erreur]);
            }
            else{
                strcpy(text, "ERREUR_NON_RECONNU");
            }
            break;

        default:
            *Erreur = ERREUR_JETON_INCO;
            strcpy(text, "INCO");
    }
    return text;
}

void afficher(Noeud * ArbreBin, Noeud * racine, int profondeur, TypeErreur * Erreur){
    int i;
    static const char space[7] = "|->|->";
    if (ArbreBin){
        for (i=0; i<profondeur; i++){
            printf("%s", space);
        }
        char * NomJeton = nom_jeton(ArbreBin->ele, Erreur);
        printf("  %s\n", NomJeton);
        if (NomJeton){
            free(NomJeton);
        }
        
        afficher(ArbreBin->fg, racine, profondeur+1, Erreur);
        afficher(ArbreBin->fd, racine, profondeur+1, Erreur);
    }
}

