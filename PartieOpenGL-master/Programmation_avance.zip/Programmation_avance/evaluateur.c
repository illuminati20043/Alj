#include "evaluateur.h"
#include "jeton.h"

//evalue la valeur du code grace a de la recursivite

float Evaluateur(Noeud* ArbreBin, float X, TypeErreur*Erreur){
	float temp;
	float temp1;
	//si c'est vide
	if (ArbreBin == NULL) {
		return 0;
	}
	//cas ou il y a reel
	switch (ArbreBin->ele.lexem) {
	case REEL:
		return ArbreBin->ele.valeur.reel;
		break;
	//cas ou il y a variable x
	case VARIABLE:
		return X;
		break;
	//cas operateur
	case OPERATEUR:
		switch (ArbreBin->ele.valeur.operateur) {

		case PLUS:
			return Evaluateur(ArbreBin->fg, X, Erreur) + Evaluateur(ArbreBin->fd, X, Erreur); 
			
		case MOINS:
			return Evaluateur(ArbreBin->fg, X, Erreur) - Evaluateur(ArbreBin->fd, X, Erreur); 
			
		case FOIS:
			return Evaluateur(ArbreBin->fg, X, Erreur) *Evaluateur(ArbreBin->fd, X, Erreur); 
		case PUIS:
			temp = Evaluateur(ArbreBin->fd, X, Erreur);
			temp1 = Evaluateur(ArbreBin->fg, X, Erreur);
			if (temp<1){
				if (temp1>=0){
					return pow(temp1,temp);
				}
				*Erreur = ERREUR_DIV_PAR_ZERO;
				return 0;
			}
			else{
				return pow(temp1,temp);
			}
			 
			
		
		case DIV:
			if (ArbreBin->fd->ele.valeur.reel == 0) {
				*Erreur = ERREUR_DIV_PAR_ZERO;
				return 0;
			}
			else{
				temp = Evaluateur(ArbreBin->fd, X, Erreur);
				if(temp!=0){
					return Evaluateur(ArbreBin->fg, X, Erreur) / temp;
				}
				else{
					*Erreur = ERREUR_DIV_PAR_ZERO;
					return 0;
				}
				
			}
		default:
			*Erreur = ERREUR_OPE_INCO;
			return 0;
		}


	//cas fonction
	case FONCTION:
		switch (ArbreBin->ele.valeur.fonction) {
		case SIN:
			return sin(Evaluateur(ArbreBin->fd, X, Erreur));
			break;
		case SQRT:
			temp = Evaluateur(ArbreBin->fd, X, Erreur);
			if (temp>=0){
				return sqrt(temp);
			}
			else{
				*Erreur = ERREUR_DIV_PAR_ZERO;
				return 0;
			}
			break;
		case COS:
			return cos(Evaluateur(ArbreBin->fd, X, Erreur));
			break;
		case TAN:
			return tan(Evaluateur(ArbreBin->fd, X, Erreur));
			break;
		case EXP:
			return exp(Evaluateur(ArbreBin->fd, X, Erreur));
			break;
		case LOG:
			return log(Evaluateur(ArbreBin->fd, X, Erreur));
			break;
		case ENTIER:
			return floor(Evaluateur(ArbreBin->fd, X, Erreur));
			break;
		case VAL_NEG:
			return -Evaluateur(ArbreBin->fd, X, Erreur);
			break;

		default:
			*Erreur = ERREUR_FCT_INCO;
			return 0;
		}

	}
}






