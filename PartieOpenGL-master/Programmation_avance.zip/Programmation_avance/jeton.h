#ifndef JETON_
#define JETON_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

#define PRIO_ADD_SOUS 1
#define PRIO_MLT_DIV 2
#define PRIO_PUIS 3
#define PAR_A_ENLV -2
#define TAILLE_TAB_JETONS 200
//énumération des différents types de lexems existants
typedef enum{
    REEL, OPERATEUR, FONCTION, ERREUR, PAR_OUV, PAR_FERM, VARIABLE, FIN 
}TypeLexem;

//énumération des différents types d'opérateurs existants
typedef enum{
    PLUS, MOINS, FOIS, DIV, PUIS
}TypeOperateur;

//énumération des différents types de fonctions existantes
typedef enum{
    SIN, COS, ABS, SQRT, LOG, TAN, EXP, ENTIER, VAL_NEG
}TypeFonction;

//énumération des différents types d'erreurs
typedef enum{
    AUCUNE, 
    ERREUR_ABS_SIGNE_FOIS,
    ERREUR_OPERATEUR, 
    ERREUR_PARENTHESES, 
    ERREUR_FCT_SANS_PARAM,
    ERREUR_TROP_CARACT_FANT,
    ERREUR_MALLOC, 
    ERREUR_FCT_INCO,
    ERREUR_OPE_INCO,
    ERREUR_JETON_INCO,
    ERREUR_CHAR_INCO,
    ERREUR_REEL_INVALIDE,
    ERREUR_DIV_PAR_ZERO
 
    
}TypeErreur;

//énumération des différents types de valeurs existantes
typedef struct{
    float reel;
    TypeFonction fonction;
    TypeOperateur operateur;
    TypeErreur erreur;
}TypeValeur;

typedef struct{
    TypeLexem lexem;
    TypeValeur valeur;
}typejeton;


typedef struct Noeud{
    typejeton ele;
    struct Noeud * fg;
    struct Noeud * fd;
}Noeud;

#endif
