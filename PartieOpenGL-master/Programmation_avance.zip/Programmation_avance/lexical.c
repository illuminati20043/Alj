#include "lexical.h"


int lire_jeton(char* s, typejeton T[], TypeErreur* erreur) {
    int jetons = 0;
    int i = 0;
    while (s[i] != '\0') {
        if (s[i]=='('){
            T[jetons].lexem = PAR_OUV;
            i++;
            jetons++;
        }
        else if (s[i]==')'){
            T[jetons].lexem = PAR_FERM;
            i++;
            jetons++;
        }
        else if (s[i]=='+'){
            T[jetons].lexem = OPERATEUR;
            T[jetons].valeur.operateur = PLUS;
            i++;
            jetons++;
        }
        else if (s[i]=='-'){
            T[jetons].lexem = OPERATEUR;
            T[jetons].valeur.operateur = MOINS;
            i++;
            jetons++;
        }
        else if (s[i]=='*'){
            T[jetons].lexem = OPERATEUR;
            T[jetons].valeur.operateur = FOIS;
            i++;
            jetons++;
        }
        else if (s[i]=='/'){
            T[jetons].lexem = OPERATEUR;
            T[jetons].valeur.operateur = DIV;
            i++;
            jetons++;
        }
        else if (s[i]=='^'){
            T[jetons].lexem = OPERATEUR;
            T[jetons].valeur.operateur = PUIS;
            i++;
            jetons++;
        }

        else if (isalpha(s[i])) {
            char t[100];
            int j = 0;
            char lettre;
            lettre = tolower(s[i]);
            
            
            if (lettre == 'x'){
                T[jetons].lexem = VARIABLE;
                i++;
            }
            else{
                while (isalpha(s[i]) && j < 99) {

                    //t[j++] = s[i++];                    
                    lettre = tolower(s[i]);
                    t[j] = lettre;
                    
                    i++;
                    j++;
                    
                }
                t[j] = '\0';
                if (strcmp(t, "abs") == 0) {
                    T[jetons].lexem = FONCTION;
                    T[jetons].valeur.fonction = ABS;
                }
                else if (strcmp(t, "exp") == 0) {
                    T[jetons].lexem = FONCTION;
                    T[jetons].valeur.fonction = EXP;
                }
                else if (strcmp(t, "sin") == 0) {
                    T[jetons].lexem = FONCTION;
                    T[jetons].valeur.fonction = SIN;
                }
                else if (strcmp(t, "cos") == 0) {
                    T[jetons].lexem = FONCTION;
                    T[jetons].valeur.fonction = COS;
                }
                else if (strcmp(t, "tan") == 0) {
                    T[jetons].lexem = FONCTION;
                    T[jetons].valeur.fonction = TAN;
                }
                else if (strcmp(t, "sqrt") == 0) {
                    T[jetons].lexem = FONCTION;
                    T[jetons].valeur.fonction = SQRT;
                }
                else if (strcmp(t, "entier") == 0) {
                    T[jetons].lexem = FONCTION;
                    T[jetons].valeur.fonction = ENTIER;
                }
                else if (strcmp(t, "valneg") == 0) {
                    T[jetons].lexem = FONCTION;
                    T[jetons].valeur.fonction = VAL_NEG;
                }
                else if (strcmp(t, "x") == 0) {
                    T[jetons].lexem = VARIABLE;
                }
                else {
                    printf("FCT INCO:%s", t);
                    T[jetons].lexem = ERREUR;
                    T[jetons].valeur.erreur = ERREUR_CHAR_INCO;	//char invalide
                    *erreur = ERREUR_CHAR_INCO;
                }
            }
            jetons++;
        }
        else if (isdigit(s[i])) {
                char t[100];
                int j = 0;
                int compteurPoints = 0;
                while (isdigit(s[i]) || s[i] == '.') {
                    if (s[i] == '.') {
                        compteurPoints++;
                    }
                    t[j++] = s[i++];
                }
                t[j] = '\0';
                if (compteurPoints <= 1) {
                    T[jetons].lexem = REEL;
                    T[jetons].valeur.reel = atof(t);
                }
                // reel invalide
                else {
                    T[jetons].lexem = ERREUR;
                    T[jetons].valeur.erreur = ERREUR_REEL_INVALIDE;	//reel invalide
                    *erreur = ERREUR_REEL_INVALIDE;
                }
                jetons++;
            }
            else

                // Ignorer les espaces
                if (isspace(s[i])) {
                    i++;
                }

        // char inconnu
                else {
                    T[jetons].lexem = ERREUR;
                    T[jetons].valeur.erreur = ERREUR_CHAR_INCO;	//char inconnu
                    *erreur = ERREUR_CHAR_INCO;
                    jetons++;
                }
    }
    if (jetons<199){
        typejeton fin;
        fin.lexem=FIN;
        T[jetons] = fin;
    }
    return jetons;
}

void afficher_jeton(typejeton jeton[], int nb_jetons) {
    for (int i = 0; i < nb_jetons; i++) {
        switch (jeton[i].lexem) {
        case REEL:
            printf("REEL: %f\n", jeton[i].valeur.reel);
            break;
        case OPERATEUR:
            printf("OPERATEUR: %d\n", jeton[i].valeur.operateur);
            break;
        case FONCTION:
            printf("FONCTION: %d\n", jeton[i].valeur.fonction);
            break;
        case ERREUR:
            printf("ERREUR: %d\n", jeton[i].valeur.erreur);
            break;
        case FIN:
            printf("FIN\n");
            break;
        case PAR_OUV:
            printf("PAR_OUV\n");
            break;
        case PAR_FERM:
            printf("PAR_FERM\n");
            break;
        case VARIABLE:
            printf("VARIABLE: X \n");
            break;
        default:
            printf("Type inconnu\n");
            break;
        }
    }
}