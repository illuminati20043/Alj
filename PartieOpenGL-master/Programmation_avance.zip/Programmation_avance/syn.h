#ifndef SYN_
#define SYN_
#include "jeton.h"




/**
* Ajoute un jeton à un tableau de jetons à un Index
* @param Syntaxe Un Tableau de Jetons non vide
* @param Jeton Un Jeton a ajouter au tableau Syntaxe
* @param Index Indice ou il faut ajouter le jeton
* @param Erreur Pointeur sur une structure stockant le type d erreurs si elles surviennent
* @return Rien
*/
void AjouterJeton(typejeton Syntaxe[TAILLE_TAB_JETONS], typejeton Jeton, int Index, TypeErreur*Erreur);


/**
* Ajoute les termes muets d une expression et controle les erreurs lies aux parentheses
* @param Syntaxe Un Tableau de Jetons non vide
* @param Erreur Pointeur sur une structure stockant le type d erreurs si elles surviennent
* @return Rien
*/
void AjouterTermesMuets(typejeton Syntaxe[TAILLE_TAB_JETONS], TypeErreur*Erreur);


/**
* Détecte les erreurs liees a l organisation des jetons dans l arbre
* @param ArbreBin un noeud d'un arbre binaire de jetons
* @param Erreur Pointeur sur une structure stockant le type d erreurs si elles surviennent
* @return Rien
*/
void DetecterErreurArbre(Noeud * ArbreBin, TypeErreur*Erreur);

/**
* Creer l arbre binaire associe au tableau de jetons de facon recursive
* @param Syntaxe Un Tableau de Jetons non vide
* @param IndexDebut Index du debut du tableau
* @param IndexFin Index du fin du tableau
* @param Erreur Pointeur sur une structure stockant le type d erreurs si elles surviennent
* @return L arbre binaire associe au tableau de jetons respectant les regles definis
*/
Noeud * creer_arbre(typejeton Syntaxe[TAILLE_TAB_JETONS], int IndexDebut, int IndexFin, TypeErreur*erreur);

/**
* Cree un noeud d'un arbre binaire contenant un jeton
* @param jeton Un jeton
* @param Erreur Pointeur sur une structure stockant le type d erreurs si elles surviennent
* @return Un noeud d'un arbre binaire contenant le jeton
*/
Noeud * creer_noeud(typejeton jeton, TypeErreur * Erreur);


/**
* Renvoie l index de la parenthese qui ferme la parenthese situe avant l'indice IndexDebut du tableau
* @param Syntaxe Un Tableau de Jetons
* @param IndexDebut Index du debut du tableau
* @param IndexFin Index du fin du tableau
* @param Erreur Pointeur sur une structure stockant le type d erreurs si elles surviennent
* @return index de la parenthese qui ferme celle situe a IndexDebut du tableau de jetons
*/
int index_fin_parenthese(typejeton Syntaxe[TAILLE_TAB_JETONS], int IndexDebut, int IndexFin, TypeErreur * Erreur);


/**
* Renvoie l index du tableau de jetons a mettre en haut de l'arbre binaire
* @param Syntaxe Un Tableau de Jetons
* @param IndexDebut Index du debut du tableau
* @param IndexFin Index du fin du tableau
* @param Erreur Pointeur sur une structure stockant le type d erreurs si elles surviennent
* @return index du tableau de jetons a mettre en haut de l'arbre binaire
*/
int index_noeud(typejeton Syntaxe[TAILLE_TAB_JETONS], int IndexDebut, int IndexFin, TypeErreur * Erreur);


/**
* Renvoie le dernier index du tableau correspondant à la priorite demande
* @param Syntaxe Un Tableau de Jetons
* @param IndexDebut Index du debut du tableau
* @param IndexFin Index du fin du tableau
* @param Priorite PRIO_ADD_SOUS (+ ou -) ou PRIO_MLT_DIV (* ou /)
* @param Erreur Pointeur sur une structure stockant le type d erreurs si elles surviennent
* @return index du tableau de jetons a mettre en haut de l'arbre binaire. -1 si l'indice n a pas ete trouve
*/
int chercher_index(typejeton Syntaxe[TAILLE_TAB_JETONS], int IndexDebut, int IndexFin, int Priorite);

#endif