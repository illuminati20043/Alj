#include "syn.h"


void AjouterJeton(typejeton Syntaxe[TAILLE_TAB_JETONS], typejeton Jeton, int Index,  TypeErreur*Erreur){
    int i = Index; // Indice ou il faut ajouter un jeton
    typejeton temp1; 
    typejeton temp2; // Variables temporaires pour stocker les jetons et realiser un decalage des indices 
    temp1 = Syntaxe[i]; 
    Syntaxe[i] = Jeton; // On ajoute le jeton en premiere position
    
    //Boucle pour decaler tous les autres jetons
    while(i<TAILLE_TAB_JETONS+1 && Syntaxe[i].lexem != FIN){
        i++;
        temp2 = Syntaxe[i]; // On stocke le jeton pour le stocker dans la case suivante
        Syntaxe[i] = temp1; // On remplit la case du tableau
        temp1 = temp2; //On charge dans temp1 le prochain jeton a affecter
    }
    i++;
    if (i<TAILLE_TAB_JETONS){
        Syntaxe[i] = temp2; // On ajoute le jeton FIN
    }
    else{
        *Erreur = ERREUR_TROP_CARACT_FANT; //S il n y a plus de place, il y a une erreur (trop de caracteres muets)
    }
}


void AjouterTermesMuets(typejeton Syntaxe[TAILLE_TAB_JETONS], TypeErreur*Erreur){
    int i = 0;
    int NbParOuv = 0; // Nombre de parentheses ouvertes
    int NbParFerm = 0; // Nombre de parentheses fermees
    int JetonsSuppl = 0; // Nombre de jetons ajoutes
    
    //On boucle sur tout le tableau
    while(i+JetonsSuppl<TAILLE_TAB_JETONS && Syntaxe[i].lexem != FIN){
        if (Syntaxe[i].lexem==PAR_OUV){
            NbParOuv +=1;
            if (i>0 && (Syntaxe[i-1].lexem == PAR_FERM||Syntaxe[i-1].lexem==VARIABLE||Syntaxe[i-1].lexem == REEL)){
                //Terme muet: Le "*" entre deux parentheses: (expression)(expression) = (expression)*(expression)
                typejeton Jeton;
                Jeton.lexem = OPERATEUR;
                Jeton.valeur.operateur = FOIS;
                AjouterJeton(Syntaxe, Jeton, i, Erreur); // On ajout du '*' muet
                i++; 
                JetonsSuppl++; 
            }       
        }
        else if (Syntaxe[i].lexem==PAR_FERM){
            NbParFerm +=1;
            if (NbParFerm > NbParOuv){
                //On ne commence par une parenthese fermee : ex: )5( 
                *Erreur = ERREUR_PARENTHESES;
            }
        }
        else if (Syntaxe[i].lexem==VARIABLE){ 
            if(i>0 && Syntaxe[i-1].lexem == REEL){
                //1er Terme muet: Le "*" avec le reel qui precede une variable: 5x = 5*x
                //2eme Terme muet: les "()" car le reel est "associé" a la variable: sin 5x = sin(5*x)
                typejeton Jeton;
                Jeton.lexem = PAR_OUV;
                AjouterJeton(Syntaxe, Jeton, i-1, Erreur); // ajout du '(' muette
                Jeton.lexem = OPERATEUR;
                Jeton.valeur.operateur = FOIS;
                AjouterJeton(Syntaxe, Jeton, i+1, Erreur); // ajout du '*' muet
                Jeton.lexem = PAR_FERM;
                AjouterJeton(Syntaxe, Jeton, i+3, Erreur); // ajout du ')' muette
                i+=3; 
                JetonsSuppl+=3;  
            }
        }
        else if (Syntaxe[i].lexem==FONCTION){
            //Terme muet: Le "*" avec le reel, la parenthese ferme, ou la variable qui precede une fonction: 
            //(5+3)sin(x) = (5+3)*sin(x) | xsin(x) = x*sin(x) | 5sin(x) = 5*sin(x)
            if(i>0 && (Syntaxe[i-1].lexem == REEL||Syntaxe[i-1].lexem == VARIABLE||Syntaxe[i-1].lexem == PAR_FERM)){
                typejeton Jeton;
                Jeton.lexem = OPERATEUR;
                Jeton.valeur.operateur = FOIS;
                AjouterJeton(Syntaxe, Jeton, i, Erreur); //ajout du '*' muet
                i++;
                JetonsSuppl++;
            }
        }
        i++;
    }
    if (NbParFerm!=NbParOuv){
        *Erreur = ERREUR_PARENTHESES;//Il faut que toutes les parentheses soient fermees
    }
}


void DetecterErreurArbre(Noeud * ArbreBin, TypeErreur*Erreur){
    if(ArbreBin->ele.lexem==OPERATEUR){ 
        if (!ArbreBin->fd){
            /*
            Un operateur a toujours un operande à droite au minimun et les doublons sont interdits
            Ex: 5+ est interdit
                5**6 est interdit
                5++6 est interdit
            */
            *Erreur = ERREUR_OPERATEUR;
        }
        else if(!ArbreBin->fg && (ArbreBin->ele.valeur.operateur == FOIS ||ArbreBin->ele.valeur.operateur == DIV || ArbreBin->ele.valeur.operateur == PUIS)){
            /*
            Les operateurs "*" et "/" ont toujours deux operandes
            Ex: *5 est interdit
                *5*6 est interdit
            */
            *Erreur = ERREUR_OPERATEUR;
        }
    } 
    else if(ArbreBin->ele.lexem==FONCTION){
        if (!ArbreBin->fd){
            //Une fonction doit toujours contenir un unique paramètre
            *Erreur = ERREUR_FCT_SANS_PARAM;
        }
    }
    else if(ArbreBin->ele.lexem==VARIABLE || ArbreBin->ele.lexem==REEL){
        if (ArbreBin->fd ||ArbreBin->fg){
            //Les variable et les reels sont forcement les feuilles de l'arbre
            *Erreur = ERREUR_ABS_SIGNE_FOIS;
        }
    }
}

Noeud * creer_arbre(typejeton Syntaxe[TAILLE_TAB_JETONS], int IndexDebut, int IndexFin, TypeErreur*erreur){
    // Condition d'arret
    if (IndexFin>IndexDebut){
        
        int IndexJeton = index_noeud(Syntaxe, IndexDebut, IndexFin, erreur); //On cherche l'index du jeton à mettre en haut de l'arbre
        
        //Si l'expression est comprise entièrement dans des parenthèses, on enlève les parenthèses en modifiant l'intervalle d etude
        if (IndexJeton == PAR_A_ENLV){
            IndexFin = index_fin_parenthese(Syntaxe, IndexDebut+1, IndexFin, erreur);
            IndexDebut++;
            return creer_arbre(Syntaxe, IndexDebut, IndexFin, erreur); //On cree l'arbre associe a l expression sont ces parentheses
        }
        //Si il n'y a pas d'erreurs, on crée l'arbre, par récursivité
        else if (IndexJeton != -1){
            //A chaque appel récursif, on ajoute un jeton sur un noeud et on rappelle la fonction pour créer ses fils gauche et droit
            Noeud *  ArbreBin = creer_noeud(Syntaxe[IndexJeton], erreur);
            ArbreBin->fg = creer_arbre(Syntaxe, IndexDebut,IndexJeton, erreur); 
            ArbreBin->fd = creer_arbre(Syntaxe, IndexJeton+1, IndexFin, erreur);

            //S'il n'y a pas déjà une erreur, on verifie que la syntaxe est correcte
            if (*erreur==AUCUNE){
                DetecterErreurArbre(ArbreBin, erreur); 
            }   
            return ArbreBin;     
        }   
    }
    return NULL;
    
}

Noeud * creer_noeud(typejeton jeton, TypeErreur * Erreur){
    Noeud *  ArbreBin = (Noeud*) malloc(sizeof(Noeud));
    if (ArbreBin){
        ArbreBin->ele = jeton;
        ArbreBin->fg = NULL;
        ArbreBin->fd = NULL;
        return ArbreBin;
    }
    // S il y a une erreur d'allocation dynamique on detecte l erreur
    else{
        *Erreur = ERREUR_MALLOC;
        return NULL;
    }
}


int index_fin_parenthese(typejeton Syntaxe[TAILLE_TAB_JETONS], int IndexDebut, int IndexFin, TypeErreur * Erreur){
    int i = IndexDebut;
    int DegreeParenthese = 1; // Il y a une parenthese ouvrante avant l'indice IndexDebut
    while (i<IndexFin && Syntaxe[i].lexem != FIN){ 
        if(Syntaxe[i].lexem == PAR_OUV) {
            DegreeParenthese++;
        }
        else if(Syntaxe[i].lexem == PAR_FERM) {
            DegreeParenthese--;
            //Il faut que la parenthese ferme la parenthese ouvrante avant l'indice IndexDebut
            if (!DegreeParenthese){
                if (i<IndexFin && (Syntaxe[i+1].lexem == FIN||Syntaxe[i+1].lexem == OPERATEUR)){
                    return i;
                }
                //S il y a un terme apres la parenthese, autre qu'une parenthese il y a erreur
                else{
                    *Erreur = ERREUR_ABS_SIGNE_FOIS; 
                    // Ex: (2+3)5
                    return i;
                }
            }
        }
        i++;
    }
    *Erreur = ERREUR_PARENTHESES; // S il ne trouve pas la parenthese fermante, il y a erreur dans les parentheses
    return IndexDebut;
}


int index_noeud(typejeton Syntaxe[TAILLE_TAB_JETONS], int IndexDebut, int IndexFin, TypeErreur * Erreur){
    // On commence par la recherche d'un jeton de priorité PRIO_ADD_SOUS (+ ou -)  
    int index = chercher_index(Syntaxe, IndexDebut, IndexFin, PRIO_ADD_SOUS);
    //S'il un operateur "+" ou "-" a été trouvé en dehors de parenthèses, on retourne l'indice du jeton
    if (index!=-1){
        return index;
    }
    else{
        // On recherche ensuite un jeton de priorité PRIO_MLT_DIV (* ou /)
        index = chercher_index(Syntaxe, IndexDebut, IndexFin, PRIO_MLT_DIV);
        //S'il un operateur "*" ou "/" a été trouvé en dehors de parenthèses, on retourne l'indice du jeton
        if (index!= -1){
            return index;
        }
        else{
            // On recherche ensuite un jeton de priorité PRIO_MLT_DIV (* ou /)
            index = chercher_index(Syntaxe, IndexDebut, IndexFin, PRIO_PUIS);
            //S'il un operateur "*" ou "/" a été trouvé en dehors de parenthèses, on retourne l'indice du jeton
            if (index!= -1){
                return index;
            }
            //Sinon si l'expression est sous parenthèses, on enlève les parenthèses
            else if(Syntaxe[IndexDebut].lexem == PAR_OUV){
                return PAR_A_ENLV;
            }
            //Sinon si c'est la fin de l'expression on retourne -1 pour arrêter la récursion
            else if (Syntaxe[IndexDebut].lexem == FIN){
                return -1;
            }
            //Sinon on retourne le premier indice: ex: sin(x)
            else{
                return IndexDebut;
            }

        }
        
    } 
}

int chercher_index(typejeton Syntaxe[TAILLE_TAB_JETONS], int IndexDebut, int IndexFin, int priorite){
    int i = IndexDebut;
    int DegreeParenthese = 0; // Permet de savoir si on se situe entre deux parentheses
    int index = -1; 
    while (i<IndexFin && Syntaxe[i].lexem != FIN){
        switch (priorite){
            case PRIO_ADD_SOUS:
                //On cherche un '+' ou un '-' en dehors des parentheses
                if (Syntaxe[i].lexem == OPERATEUR && !DegreeParenthese && (Syntaxe[i].valeur.operateur == PLUS || Syntaxe[i].valeur.operateur == MOINS)){
                    index = i;
                }
                else if(Syntaxe[i].lexem == PAR_OUV) {
                    DegreeParenthese++;
                }
                else if(Syntaxe[i].lexem == PAR_FERM) {
                    DegreeParenthese--;
                }
                break;
            case PRIO_MLT_DIV:
                //On cherche un '*' ou un '/' ou en dehors des parentheses
                if (Syntaxe[i].lexem == OPERATEUR && !DegreeParenthese && (Syntaxe[i].valeur.operateur == FOIS || Syntaxe[i].valeur.operateur == DIV)){
                    index = i;
                }
                else if(Syntaxe[i].lexem == PAR_OUV) {
                    DegreeParenthese++;
                }
                else if(Syntaxe[i].lexem == PAR_FERM) {
                    DegreeParenthese--;
                }
                break;  
            case PRIO_PUIS:  
                //On cherche un '*' ou un '/' ou en dehors des parentheses
                if (Syntaxe[i].lexem == OPERATEUR && !DegreeParenthese && Syntaxe[i].valeur.operateur == PUIS){
                    index = i;
                }
                else if(Syntaxe[i].lexem == PAR_OUV) {
                    DegreeParenthese++;
                }
                else if(Syntaxe[i].lexem == PAR_FERM) {
                    DegreeParenthese--;
                }
                break;  
        }
        i++;
    }   
    return index;
}
