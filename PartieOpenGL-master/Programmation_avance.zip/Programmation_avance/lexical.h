#ifndef LEXICAL_H
#define LEXICAL_H
#include "jeton.h"




int lire_jeton(char* s, typejeton T[], TypeErreur* erreur);

void afficher_jeton(typejeton jeton[], int nb_jetons);


#endif 