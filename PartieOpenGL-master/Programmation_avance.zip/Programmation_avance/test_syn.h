#ifndef TEST_SYN_
#define TEST_SYN_
#include "jeton.h"
void test(typejeton Syntaxe[TAILLE_TAB_JETONS], int NumTest);
char * nom_jeton(typejeton jeton, TypeErreur * Erreur);
void afficher(Noeud * ArbreBin, Noeud * racine, int profondeur, TypeErreur * Erreur);
void AfficherJetons(typejeton Syntaxe[TAILLE_TAB_JETONS],  int IndexFin, TypeErreur * Erreur);

#endif