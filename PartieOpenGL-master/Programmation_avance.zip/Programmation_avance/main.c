#include "syn.h"
#include "test_syn.h"
#include "lexical.h"
#include "evaluateur.h"

int main(int nbarg, char**argv){
    typejeton Syntaxe[TAILLE_TAB_JETONS];
    TypeErreur erreur =AUCUNE;
    char fonction[200]; 
    
    while(!erreur){
        int nb;
        printf("Entrez une fonction:\n");
        
        fgets(fonction, 200, stdin);  
        
        
        printf("Fonction:%s", fonction);
        printf("Analyse:\n");
        int nb_jetons = lire_jeton(fonction, Syntaxe ,&erreur);
        afficher_jeton(Syntaxe, nb_jetons);
        if(!erreur){
            printf("\n\nTableau recu:\n");
            AfficherJetons(Syntaxe,  200, &erreur);
            printf("\nApres Traitement erreurs parentheses:\n");
            AjouterTermesMuets(Syntaxe, &erreur);
            
            AfficherJetons(Syntaxe,  200, &erreur);
            Noeud * ArbreBin= creer_arbre(Syntaxe, 0, 200, &erreur);
            
            printf("\nArbre renvoye:\n");
            afficher(ArbreBin, ArbreBin, 0, &erreur);
            
            if(!erreur){
                printf("%f", Evaluateur(ArbreBin, 5, &erreur));
            }
        }
        
        typejeton jeton;
        jeton.lexem = ERREUR;
        jeton.valeur.erreur = erreur;
        
        printf("\n Erreur: %s\n\n", nom_jeton(jeton, &erreur));
    }
    

    
    
    
    

    /*
    while(nb!=0){
        printf("test numero ?");
        scanf("%d",&nb);
        test(Syntaxe,nb);
        TypeErreur Erreur = AUCUNE;
        printf("\n\nTableau recu:\n");
        AfficherJetons(Syntaxe,  50, &Erreur);
        printf("\nApres Traitement erreurs parentheses:\n");
        AjouterTermesMuets(Syntaxe, &Erreur);
        
        AfficherJetons(Syntaxe,  50, &Erreur);
        Noeud * ArbreBin= creer_arbre(Syntaxe, 0, 50, &Erreur);
        if (Erreur == Erreur){
            printf("\nArbre renvoye:\n");
            afficher(ArbreBin, ArbreBin, 0, &Erreur);
        }
        
        typejeton jeton;
        jeton.lexem = ERREUR;
        jeton.valeur.erreur = Erreur;
        
        printf("\n Erreur: %s\n\n", nom_jeton(jeton, &Erreur));
    }

    */
    //int debut = 2;
    //int fin = 50;
    //printf("%d\n",chercher_index(Syntaxe, debut, fin));
    //printf("%s",nom_jeton(Syntaxe[chercher_index(Syntaxe, debut, fin)]));
}
